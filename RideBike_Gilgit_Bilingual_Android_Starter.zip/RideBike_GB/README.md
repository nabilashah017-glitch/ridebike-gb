# RideBike GB — bilingual bike taxi PWA

A responsive English/Urdu prototype for a bike taxi service in Gilgit-Baltistan. Includes customer ride request mockup, driver availability dashboard, indicative fare ranges, safety checklist, install prompt and basic offline caching.

## Publish using GitHub Pages
1. Sign in at https://github.com/new and create a **public** repository named `ridebike-gb`.
2. Extract this ZIP and upload all files inside this folder to the repository root (not the ZIP itself).
3. In GitHub repository open **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**, select `main` and `/(root)`, then Save.
5. Wait for the Pages deployment to finish. Your site URL should look like `https://YOUR-GITHUB-USERNAME.github.io/ridebike-gb/`.

## Install on Android
1. Open the published HTTPS site in Chrome on Android.
2. Tap **Install app** if shown, or open Chrome ⋮ → **Install app** / **Add to Home screen**.
3. Confirm. The RideBike icon should appear on your home screen.

## Current limitations
This is a frontend prototype, not a live ride-hailing service. Ride requests are not sent to drivers; fare ranges are examples, not live quotes. No user accounts, verified drivers, real-time GPS/maps, backend, notifications, or payments exist yet. Do not launch publicly for real trips until those systems, privacy terms, driver verification, emergency processes, and security have been implemented and tested.
